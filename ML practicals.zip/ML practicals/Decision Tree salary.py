
# Journal 2 - Practical 1
# Decision Tree Classifier using Salaries Dataset

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.preprocessing import LabelEncoder

# Read dataset
data = pd.read_csv("salaries.csv")

print("Salaries Dataset:")
print(data)

# Separate input and output
X = data[['Experience', 'EducationLevel']]
y = data['Salary']

# Create and train model
model = DecisionTreeClassifier(random_state=42)
model.fit(X, y)

# Predict salary categories
y_pred = model.predict(X)

print("\nActual Salary:", list(y))
print("Predicted Salary:", list(y_pred))

# Predict salary for a new person
new_person = pd.DataFrame({
    'Experience': [5],
    'EducationLevel': [2]
})

prediction = model.predict(new_person)

print("\nPredicted Salary Category:", prediction[0])

# Visualize Decision Tree
plt.figure(figsize=(12, 7))

plot_tree(
    model,
    feature_names=['Experience', 'EducationLevel'],
    class_names=model.classes_,
    filled=True
)

plt.title("Decision Tree Classifier - Salaries")
plt.show()
