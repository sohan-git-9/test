
# Practical 7: Multiple Linear Regression
# Using Insurance CSV Dataset

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

# Read CSV file
data = pd.read_csv("insurance_Practical_3.csv")

# Display dataset
print("Insurance Dataset:")
print(data)

# Separate input and output
X = data[['Age', 'BMI', 'Children']]
y = data['Charges']

# Create and train model
model = LinearRegression()
model.fit(X, y)

# Predict values
y_pred = model.predict(X)

# Print intercept and coefficients
print("\nIntercept:", model.intercept_)
print("Coefficients:", model.coef_)

# Print R2 score
print("\nR2 Score:", r2_score(y, y_pred))

# Predict insurance charges for a new person
new_person = pd.DataFrame({
    'Age': [30],
    'BMI': [25],
    'Children': [1]
})

prediction = model.predict(new_person)

print("\nPredicted Insurance Charges:", prediction[0])

# Visualization
plt.scatter(y, y_pred, color='blue')

plt.plot(
    [y.min(), y.max()],
    [y.min(), y.max()],
    color='red'
)

plt.xlabel("Actual Insurance Charges")
plt.ylabel("Predicted Insurance Charges")
plt.title("Insurance Multiple Linear Regression")
plt.show()
