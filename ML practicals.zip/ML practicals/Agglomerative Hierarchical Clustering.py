
# Journal 2 - Practical 10
# Agglomerative Hierarchical Clustering

import os
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import AgglomerativeClustering
from scipy.cluster.hierarchy import dendrogram, linkage

# Read CSV file from the same folder
folder = os.path.dirname(os.path.abspath(__file__))
data = pd.read_csv(os.path.join(folder, "shopping_data.csv"))

print("Shopping Dataset:")
print(data)

# Select Annual Income and Spending Score
X = data[['AnnualIncome', 'SpendingScore']]

# Apply Feature Scaling
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Create linkage for dendrogram
linked = linkage(X_scaled, method='ward')

# Plot Dendrogram
plt.figure(figsize=(10, 5))
dendrogram(linked)

plt.title("Hierarchical Clustering Dendrogram")
plt.xlabel("Customers")
plt.ylabel("Euclidean Distance")
plt.show()

# Create Agglomerative Clustering model
model = AgglomerativeClustering(
    n_clusters=3,
    linkage='ward'
)

# Assign clusters
data['Cluster'] = model.fit_predict(X_scaled)

print("\nCustomers with Cluster Groups:")
print(data)

# Plot Clusters
plt.figure(figsize=(8, 5))

plt.scatter(
    data['AnnualIncome'],
    data['SpendingScore'],
    c=data['Cluster'],
    cmap='viridis',
    s=100
)

plt.xlabel("Annual Income")
plt.ylabel("Spending Score")
plt.title("Hierarchical Clustering - Shopping Dataset")
plt.show()
