
# Practical 10: Logistic Regression
# Using Insurance Dataset

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.linear_model import LogisticRegression

# Read dataset
data = pd.read_csv("insurance.csv")

print("Insurance Dataset:")
print(data)

# Separate input and output
X = data[['Age']]
y = data['PurchasedInsurance']

# Create and train model
model = LogisticRegression()
model.fit(X, y)

# Predict values
y_pred = model.predict(X)

print("\nActual Values:", list(y))
print("Predicted Values:", list(y_pred))

# Predict insurance purchase for a new age
new_person = pd.DataFrame({'Age': [38]})

prediction = model.predict(new_person)

if prediction[0] == 1:
    print("\nPrediction: Insurance Purchased")
else:
    print("\nPrediction: Insurance Not Purchased")

# Visualization
plt.scatter(X, y, color='blue', label='Actual Values')

# Generate smooth age values
import numpy as np

age_range = pd.DataFrame({
    'Age': np.linspace(20, 60, 100)
})

probability = model.predict_proba(age_range)[:, 1]

plt.plot(age_range, probability, color='red',
         label='Logistic Regression Curve')

plt.xlabel("Age")
plt.ylabel("Insurance Purchase (0 or 1)")
plt.title("Logistic Regression - Insurance Dataset")
plt.legend()
plt.show()
