
# Practical 1: Split Iris Dataset

# Import the iris dataset
from sklearn.datasets import load_iris

# Load the dataset
iris = load_iris()

# Separate features and target
X = iris.data
y = iris.target

# Print feature names
print("Feature Names:")
print(iris.feature_names)

# Print target names
print("\nTarget Names:")
print(iris.target_names)

# Print features
print("\nFeatures:")
print(X)

# Print target
print("\nTarget:")
print(y)

# Print dataset shape
print("\nFeature Shape:", X.shape)
print("Target Shape:", y.shape)
