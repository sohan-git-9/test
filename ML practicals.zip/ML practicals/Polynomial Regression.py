
# Practical 8: Polynomial Regression

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures

# Read dataset
data = pd.read_csv("position_salary.csv")

print("Position Salary Dataset:")
print(data)

# Separate input and output
X = data[['Level']]
y = data['Salary']

# Convert input into polynomial features
poly = PolynomialFeatures(degree=3)
X_poly = poly.fit_transform(X)

# Create and train model
model = LinearRegression()
model.fit(X_poly, y)

# Predict salary
y_pred = model.predict(X_poly)

# Predict salary for a new level
new_level = pd.DataFrame({'Level': [6.5]})
new_poly = poly.transform(new_level)

prediction = model.predict(new_poly)

print("\nPredicted Salary for Level 6.5:", prediction[0])

# Visualization
plt.scatter(X, y, color='blue', label='Actual Salary')

plt.plot(X, y_pred, color='red', label='Polynomial Regression')

plt.xlabel("Position Level")
plt.ylabel("Salary")
plt.title("Polynomial Regression")
plt.legend()
plt.show()
