
# Practical 4: Linear Regression
# Predict Salary for 5 Years of Experience

import numpy as np
from sklearn.linear_model import LinearRegression

# Dataset
X = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).reshape(-1, 1)

y = np.array([
    20000, 25000, 30000, 35000, 40000,
    45000, 50000, 55000, 60000, 65000
])

# Create model
model = LinearRegression()

# Train model
model.fit(X, y)

# Predict salary for 5 years
experience = [[5]]

prediction = model.predict(experience)

print("Experience:", 5, "Years")
print("Predicted Salary:", prediction[0])
