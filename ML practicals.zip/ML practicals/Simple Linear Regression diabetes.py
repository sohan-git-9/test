
# Practical 2: Simple Linear Regression
# Using Diabetes Dataset

import matplotlib.pyplot as plt

from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error

# Load diabetes dataset
diabetes = load_diabetes()

# Select one feature (BMI)
X = diabetes.data[:, 2].reshape(-1, 1)

# Target value
y = diabetes.target

# Split dataset into training and testing
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Create Linear Regression model
model = LinearRegression()

# Train the model
model.fit(X_train, y_train)

# Predict values
y_pred = model.predict(X_test)

# Calculate R2 score and MSE
r2 = r2_score(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)

# Print results
print("R2 Score:", r2)
print("Mean Squared Error:", mse)

# Visualization
plt.scatter(X_test, y_test, color='blue', label='Actual Values')
plt.scatter(X_test, y_pred, color='red', label='Predicted Values')

plt.xlabel("BMI")
plt.ylabel("Diabetes Progression")
plt.title("Simple Linear Regression")
plt.legend()
plt.show()
