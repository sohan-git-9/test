
# Journal 2 - Practical 9
# K-Means Clustering using Iris Dataset

import matplotlib.pyplot as plt

from sklearn.datasets import load_iris
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# Load Iris dataset
iris = load_iris()

# Select Petal Length and Petal Width
X = iris.data[:, [2, 3]]

# Apply Feature Scaling
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Elbow Method
inertia = []

for k in range(1, 11):
    kmeans = KMeans(
        n_clusters=k,
        random_state=42,
        n_init=10
    )

    kmeans.fit(X_scaled)
    inertia.append(kmeans.inertia_)

# Plot Elbow Graph
plt.plot(range(1, 11), inertia, marker='o')
plt.xlabel("Number of Clusters (K)")
plt.ylabel("Inertia")
plt.title("Elbow Method")
plt.show()

# Create final K-Means model
kmeans = KMeans(
    n_clusters=3,
    random_state=42,
    n_init=10
)

clusters = kmeans.fit_predict(X_scaled)

# Display cluster results
print("First 20 Cluster Assignments:")
print(clusters[:20])

print("\nCluster Centers:")
print(kmeans.cluster_centers_)

# Visualize Clusters
plt.scatter(
    X_scaled[:, 0],
    X_scaled[:, 1],
    c=clusters,
    cmap='viridis',
    s=50
)

plt.xlabel("Scaled Petal Length")
plt.ylabel("Scaled Petal Width")
plt.title("K-Means Clustering - Iris Dataset")
plt.show()
