
# Practical 5: Multiple Linear Regression
# Using Local CSV Dataset

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error

# Read CSV file
data = pd.read_csv("housing.csv")

# Display dataset
print("Housing Dataset:")
print(data)

# Separate input and output
X = data[['Area', 'Bedrooms']]
y = data['Price']

# Create model
model = LinearRegression()

# Train model
model.fit(X, y)

# Predict values
y_pred = model.predict(X)

# Print intercept and coefficients
print("\nIntercept:", model.intercept_)
print("Coefficients:", model.coef_)

# Calculate R2 score and MSE
print("\nR2 Score:", r2_score(y, y_pred))
print("Mean Squared Error:", mean_squared_error(y, y_pred))

# Predict price for a new house
new_house = pd.DataFrame({
    'Area': [1500],
    'Bedrooms': [3]
})

prediction = model.predict(new_house)

print("\nPredicted House Price:", prediction[0], "Lakhs")

# Visualization
plt.scatter(y, y_pred, color='blue', label='Predicted Values')

plt.plot([y.min(), y.max()], [y.min(), y.max()],
         color='red', label='Perfect Prediction')

plt.xlabel("Actual Price (Lakhs)")
plt.ylabel("Predicted Price (Lakhs)")
plt.title("Multiple Linear Regression")
plt.legend()
plt.show()
