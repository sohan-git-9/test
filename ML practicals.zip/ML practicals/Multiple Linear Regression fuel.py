
# Practical 6: Multiple Linear Regression
# Using Fuel Consumption CSV Dataset

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error

# Read CSV file
data = pd.read_csv("fuel.csv")

# Display dataset
print("Fuel Consumption Dataset:")
print(data)

# Separate input and output
X = data[['Engine_Size', 'Cylinders', 'Fuel_Consumption']]
y = data['CO2_Emissions']

# Create and train model
model = LinearRegression()
model.fit(X, y)

# Predict values
y_pred = model.predict(X)

# Print intercept and coefficients
print("\nIntercept:", model.intercept_)
print("Coefficients:", model.coef_)

# Calculate accuracy
print("\nR2 Score:", r2_score(y, y_pred))
print("Mean Squared Error:", mean_squared_error(y, y_pred))

# Display actual and predicted values
print("\nActual vs Predicted CO2 Emissions:")

for actual, predicted in zip(y, y_pred):
    print("Actual:", actual,
          "Predicted:", round(predicted, 2),
          "Difference:", round(actual - predicted, 2))

# Visualization
plt.scatter(y, y_pred, color='blue')
plt.plot([y.min(), y.max()],
         [y.min(), y.max()], color='red')

plt.xlabel("Actual CO2 Emissions")
plt.ylabel("Predicted CO2 Emissions")
plt.title("Fuel Consumption - Multiple Linear Regression")
plt.show()
