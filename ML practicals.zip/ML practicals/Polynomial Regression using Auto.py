
# Practical 9: Polynomial Regression using Auto Dataset

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import r2_score, mean_squared_error

# Read dataset
data = pd.read_csv("auto.csv")

print("Auto Dataset:")
print(data)

# Separate input and output
X = data[['Horsepower']]
y = data['MPG']

# Convert input into polynomial features
poly = PolynomialFeatures(degree=2)
X_poly = poly.fit_transform(X)

# Create and train model
model = LinearRegression()
model.fit(X_poly, y)

# Predict values
y_pred = model.predict(X_poly)

# Calculate R2 score and MSE
print("\nR2 Score:", r2_score(y, y_pred))
print("Mean Squared Error:", mean_squared_error(y, y_pred))

# Visualization
plt.scatter(X, y, color='blue', label='Actual Values')

plt.plot(X, y_pred, color='red', label='Polynomial Prediction')

plt.xlabel("Horsepower")
plt.ylabel("Miles Per Gallon (MPG)")
plt.title("Polynomial Regression - Auto Dataset")
plt.legend()
plt.show()
