
# Journal 2 - Practical 8
# K-Means Clustering using People Dataset

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.cluster import KMeans

# Read CSV file
data = pd.read_csv("people.csv")

print("People Dataset:")
print(data)

# Select Age and Income
X = data[['Age', 'Income']]

# Create K-Means model
kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)

# Train model and assign clusters
data['Cluster'] = kmeans.fit_predict(X)

# Display results
print("\nPeople with Cluster Groups:")
print(data)

# Display cluster centers
print("\nCluster Centers:")
print(kmeans.cluster_centers_)

# Visualization
plt.scatter(
    data['Age'],
    data['Income'],
    c=data['Cluster'],
    cmap='viridis',
    s=100
)

plt.xlabel("Age")
plt.ylabel("Income")
plt.title("K-Means Clustering - People Dataset")
plt.show()
