
# Journal 2 - Practical 4
# SVM Iris Species Prediction

from sklearn.datasets import load_iris
from sklearn.svm import SVC

# Load Iris dataset
iris = load_iris()

X = iris.data
y = iris.target

# Create SVM model
model = SVC(kernel='linear')

# Train model
model.fit(X, y)

# Take new flower measurements
new_flower = [[5.1, 3.5, 1.4, 0.2]]

# Predict species
prediction = model.predict(new_flower)

# Display result
print("New Flower Measurements:", new_flower)

print("Predicted Iris Species:",
      iris.target_names[prediction[0]])
