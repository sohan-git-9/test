
# Practical 3: Linear Regression with Different Datasets

from sklearn.linear_model import LinearRegression
import numpy as np

# Create a function for Linear Regression
def predict_value(x, y, new_value, name):

    # Convert data into arrays
    X = np.array(x).reshape(-1, 1)
    Y = np.array(y)

    # Create model
    model = LinearRegression()

    # Train model
    model.fit(X, Y)

    # Predict new value
    prediction = model.predict([[new_value]])

    print("\n", name)
    print("Input Value:", new_value)
    print("Predicted Value:", prediction[0])


# 1. Age and Height
predict_value(
    [5, 10, 15, 20, 25],
    [105, 135, 160, 170, 172],
    18,
    "Age and Height"
)

# 2. Standard and Percentage
predict_value(
    [8, 9, 10, 11, 12],
    [65, 70, 75, 80, 85],
    11,
    "Standard and Percentage"
)

# 3. Height and Shoe Size
predict_value(
    [150, 160, 170, 180, 190],
    [5, 6, 7, 8, 9],
    175,
    "Height and Shoe Size"
)

# 4. Experience and Salary
predict_value(
    [1, 2, 3, 4, 5],
    [15000, 20000, 25000, 30000, 35000],
    5,
    "Experience and Salary"
)

# 5. Hours and Score
predict_value(
    [1, 2, 3, 4, 5],
    [20, 40, 60, 80, 100],
    6,
    "Hours and Score"
)

# 6. Vehicle Age and Resale Price
predict_value(
    [1, 2, 3, 4, 5],
    [900000, 800000, 700000, 600000, 500000],
    3,
    "Vehicle Age and Resale Price"
)
