
# Practical 11: Logistic Regression
# Using Heart Dataset

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

from sklearn.linear_model import LogisticRegression

# Read dataset
data = pd.read_csv("heart.csv")

print("Heart Dataset:")
print(data)

# Separate input and output
X = data[['Age', 'Cholesterol', 'MaxHeartRate']]
y = data['HeartDisease']

# Create and train model
model = LogisticRegression()
model.fit(X, y)

# Predict values
y_pred = model.predict(X)

print("\nActual Values:", list(y))
print("Predicted Values:", list(y_pred))

# Predict for a new person
new_person = pd.DataFrame({
    'Age': [45],
    'Cholesterol': [220],
    'MaxHeartRate': [165]
})

prediction = model.predict(new_person)

if prediction[0] == 1:
    print("\nPrediction: Heart Disease Detected")
else:
    print("\nPrediction: No Heart Disease Detected")

# Visualization
age_range = np.linspace(25, 70, 100)

# Keep other features at their average values
plot_data = pd.DataFrame({
    'Age': age_range,
    'Cholesterol': [data['Cholesterol'].mean()] * 100,
    'MaxHeartRate': [data['MaxHeartRate'].mean()] * 100
})

probability = model.predict_proba(plot_data)[:, 1]

plt.scatter(data['Age'], y, color='blue',
            label='Actual Values')

plt.plot(age_range, probability, color='red',
         label='Logistic Regression Curve')

plt.xlabel("Age")
plt.ylabel("Heart Disease Probability")
plt.title("Logistic Regression - Heart Dataset")
plt.legend()
plt.show()
