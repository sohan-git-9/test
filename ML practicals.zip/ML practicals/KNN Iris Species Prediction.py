
# Journal 2 - Practical 7
# KNN Iris Species Prediction

from sklearn.datasets import load_iris
from sklearn.neighbors import KNeighborsClassifier

# Load Iris dataset
iris = load_iris()

X = iris.data
y = iris.target

# Create KNN model
model = KNeighborsClassifier(n_neighbors=5)

# Train model
model.fit(X, y)

# New flower measurements
new_flower = [[5.1, 3.5, 1.4, 0.2]]

# Predict species
prediction = model.predict(new_flower)

# Display result
print("New Flower Measurements:", new_flower)

print("Predicted Iris Species:",
      iris.target_names[prediction[0]])
