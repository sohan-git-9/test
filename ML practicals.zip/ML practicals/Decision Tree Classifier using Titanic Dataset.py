
# Journal 2 - Practical 2
# Decision Tree Classifier using Titanic Dataset

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import accuracy_score

# Read dataset
data = pd.read_csv("titanic.csv")

print("Titanic Dataset:")
print(data)

# Separate input and output
X = data[['Age', 'Gender', 'PassengerClass']]
y = data['Survived']

# Create and train model
model = DecisionTreeClassifier(random_state=42)
model.fit(X, y)

# Predict survival
y_pred = model.predict(X)

print("\nActual Values:", list(y))
print("Predicted Values:", list(y_pred))

# Calculate accuracy
accuracy = accuracy_score(y, y_pred)
print("\nAccuracy:", accuracy * 100, "%")

# Predict for a new passenger
new_passenger = pd.DataFrame({
    'Age': [25],
    'Gender': [1],
    'PassengerClass': [2]
})

prediction = model.predict(new_passenger)

if prediction[0] == 1:
    print("\nPassenger Survived")
else:
    print("\nPassenger Did Not Survive")

# Visualize Decision Tree
plt.figure(figsize=(12, 7))

plot_tree(
    model,
    feature_names=['Age', 'Gender', 'PassengerClass'],
    class_names=['Not Survived', 'Survived'],
    filled=True
)

plt.title("Decision Tree - Titanic Dataset")
plt.show()
